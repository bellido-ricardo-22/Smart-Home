# app.py
from rooms.habitacion import Habitacion
from devices.luz import Luz
from devices.sensor import Sensor
from devices.termostato import Termostato
from devices.camara_seguridad import CamaraSeguridad
from devices.persiana_inteligente import PersianaInteligente
from devices.cerradura_inteligente import CerraduraInteligente

class SmartHome:
    def __init__(self):
        self.habitaciones = []
        self.casa_vacia = False  # Añadido para soportar la funcionalidad de seguridad

    def agregar_habitacion(self, habitacion):
        self.habitaciones.append(habitacion)
        print(f"Habitación {habitacion} agregada.")

    def listar_habitaciones(self):
        print("Habitaciones en el hogar:")
        for habitacion in self.habitaciones:
            print(f"- {habitacion}")

    def set_casa_vacia(self, estado):
        self.casa_vacia = estado
        print(f"Casa vacía: {estado}")