# devices/camara_seguridad.py
class CamaraSeguridad:
    def __init__(self, nombre):
        self.nombre = nombre
        self.grabando = False

    def grabar(self):
        self.grabando = True
        print(f"{self.nombre} comenzó a grabar.")

    def detener_grabacion(self):
        self.grabando = False
        print(f"{self.nombre} detuvo la grabación.")

    def tomar_foto(self):
        print(f"{self.nombre} tomó una foto.")

    def __str__(self):
        estado = "grabando" if self.grabando else "no grabando"
        return f"Cámara de Seguridad {self.nombre}: {estado}"