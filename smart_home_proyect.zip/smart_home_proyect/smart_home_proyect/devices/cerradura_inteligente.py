# devices/cerradura_inteligente.py
class CerraduraInteligente:
    def __init__(self, nombre):
        self.nombre = nombre
        self.bloqueada = True  # Comienza bloqueada por defecto

    def bloquear(self):
        self.bloqueada = True
        print(f"{self.nombre} bloqueada.")

    def desbloquear(self):
        self.bloqueada = False
        print(f"{self.nombre} desbloqueada.")

    def verificar_estado(self):
        estado = "bloqueada" if self.bloqueada else "desbloqueada"
        print(f"{self.nombre} está {estado}.")

    def __str__(self):
        estado = "bloqueada" if self.bloqueada else "desbloqueada"
        return f"Cerradura Inteligente {self.nombre}: {estado}"