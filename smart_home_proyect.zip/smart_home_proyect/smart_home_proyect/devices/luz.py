# devices/luz.py
class Luz:
    def __init__(self, nombre):
        self.nombre = nombre
        self.encendida = False

    def encender(self):
        self.encendida = True
        print(f"{self.nombre} encendida.")

    def apagar(self):
        self.encendida = False
        print(f"{self.nombre} apagada.")

    def __str__(self):
        estado = "encendida" if self.encendida else "apagada"
        return f"Luz {self.nombre}: {estado}"