# devices/persiana_inteligente.py
class PersianaInteligente:
    def __init__(self, nombre):
        self.nombre = nombre
        self.nivel = 0  # 0% abierto (cerrado), 100% abierto

    def abrir(self):
        self.nivel = 100
        print(f"{self.nombre} abierta completamente.")

    def cerrar(self):
        self.nivel = 0
        print(f"{self.nombre} cerrada completamente.")

    def ajustar_nivel(self, nivel):
        if 0 <= nivel <= 100:
            self.nivel = nivel
            print(f"{self.nombre} ajustada a {nivel}% abierto.")
        else:
            print("Nivel inválido. Debe ser entre 0 y 100.")

    def __str__(self):
        return f"Persiana Inteligente {self.nombre}: {self.nivel}% abierta"