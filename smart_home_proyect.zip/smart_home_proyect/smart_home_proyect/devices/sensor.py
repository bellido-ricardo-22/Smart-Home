# devices/sensor.py
class Sensor:
    def __init__(self, nombre):
        self.nombre = nombre
        self.dato = 0.0

    def leer_dato(self):
        # Simulación de lectura de dato
        import random
        self.dato = random.random()
        print(f"{self.nombre} leyó el dato: {self.dato}")

    def hay_movimiento(self):
        # Simulación de detección de movimiento
        return self.dato > 0.5

    def __str__(self):
        return f"Sensor {self.nombre}"