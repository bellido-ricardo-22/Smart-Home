# devices/termostato.py
import random

class Termostato:
    def __init__(self, nombre):
        self.nombre = nombre
        self.temperatura_deseada = 20
        self.temperatura_actual = None

    def establecer_temperatura(self, temperatura):
        self.temperatura_deseada = temperatura
        print(f"{self.nombre} establecido a {temperatura}°C.")

    def leer_temperatura(self):
        self.temperatura_actual = random.uniform(7, 30)  # Rango ajustado para probar reglas
        print(f"{self.nombre} lee temperatura actual: {self.temperatura_actual:.1f}°C")
        return self.temperatura_actual

    def __str__(self):
        return f"Termostato {self.nombre}: {self.temperatura_deseada}°C"