# main.py
import tkinter as tk
from tkinter import messagebox
from app import SmartHome
from rooms.habitacion import Habitacion
from devices.luz import Luz
from devices.sensor import Sensor
from devices.termostato import Termostato
from devices.persiana_inteligente import PersianaInteligente
from devices.cerradura_inteligente import CerraduraInteligente
from datetime import datetime
from rules import regla_abrir_persianas_si_calor, regla_cerrar_persianas_si_frio, regla_encender_luz_si_movimiento

class SmartHomeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Home Control")

        # Cargar íconos con tamaño ajustado (16x16 asumiendo originales de 32x32)
        self.icono_sol = tk.PhotoImage(file="sol.png").subsample(10, 10)
        self.icono_luna = tk.PhotoImage(file="luna.png").subsample(4, 4)
        self.icono_encendido = tk.PhotoImage(file="encendido.png").subsample(14, 14)
        self.icono_apagado = tk.PhotoImage(file="apagado.png").subsample(5, 5)

        # Crear instancia de SmartHome
        self.hogar = SmartHome()

        # Crear habitaciones
        self.sala = Habitacion("Sala")
        self.cocina = Habitacion("Cocina")
        self.entrada = Habitacion("Entrada")
        self.cuarto = Habitacion("Cuarto")
        self.bano = Habitacion("Baño")

        # Agregar habitaciones al hogar
        self.hogar.agregar_habitacion(self.sala)
        self.hogar.agregar_habitacion(self.cocina)
        self.hogar.agregar_habitacion(self.entrada)
        self.hogar.agregar_habitacion(self.cuarto)
        self.hogar.agregar_habitacion(self.bano)

        # Crear dispositivos y agregarlos a las habitaciones
        try:
            self.luz_sala = Luz("Luz Sala")
            self.sala.agregar_dispositivo(self.luz_sala)
            self.persiana_sala = PersianaInteligente("Persiana Sala")
            self.sala.agregar_dispositivo(self.persiana_sala)
            self.termostato_sala = Termostato("Termostato Sala")
            self.sala.agregar_dispositivo(self.termostato_sala)
            self.termostato_cocina = Termostato("Termostato Cocina")
            self.cocina.agregar_dispositivo(self.termostato_cocina)
            self.sensor_movimiento_entrada = Sensor("Movimiento Entrada")
            self.entrada.agregar_dispositivo(self.sensor_movimiento_entrada)
            self.cerradura_entrada = CerraduraInteligente("Cerradura Entrada")
            self.entrada.agregar_dispositivo(self.cerradura_entrada)
            self.luz_cuarto = Luz("Luz Cuarto")
            self.cuarto.agregar_dispositivo(self.luz_cuarto)
            self.sensor_movimiento_cuarto = Sensor("Movimiento Cuarto")
            self.cuarto.agregar_dispositivo(self.sensor_movimiento_cuarto)
            self.luz_bano = Luz("Luz Baño")
            self.bano.agregar_dispositivo(self.luz_bano)
            self.termostato_bano = Termostato("Termostato Baño")
            self.bano.agregar_dispositivo(self.termostato_bano)
        except Exception as e:
            print(f"Error al inicializar dispositivos: {str(e)}")

        # Definir reglas de automatización desde rules.py
        self.reglas = [
            regla_abrir_persianas_si_calor,
            regla_encender_luz_si_movimiento,
            regla_cerrar_persianas_si_frio
        ]

        # Crear la interfaz gráfica
        self.create_widgets()
        
        # Inicia la automatización con retraso
        self.root.after(1000, self.iniciar_automatizacion)

    def iniciar_automatizacion(self):
        try:
            self.verificar_sensores()
        except Exception as e:
            self.actualizar_mensajes([f"Error en automatización: {str(e)}"])
        self.root.after(10000, self.iniciar_automatizacion)

    def create_widgets(self):
        frame_top = tk.Frame(self.root)
        frame_top.pack(pady=10)

        self.habitacion_var = tk.StringVar()
        self.habitacion_combobox = tk.OptionMenu(frame_top, self.habitacion_var, *[hab.nombre for hab in self.hogar.habitaciones], command=self.actualizar_controles)
        self.habitacion_combobox.pack(side=tk.LEFT, padx=5)

        self.casa_vacia_var = tk.BooleanVar()
        self.casa_vacia_check = tk.Checkbutton(frame_top, text="Casa Vacía", variable=self.casa_vacia_var, command=self.set_casa_vacia)
        self.casa_vacia_check.pack(side=tk.LEFT, padx=5)

        btn_verificar = tk.Button(frame_top, text="Verificar Sensores", command=self.verificar_sensores)
        btn_verificar.pack(side=tk.LEFT, padx=5)

        self.frame_controles = tk.Frame(self.root)
        self.frame_controles.pack(pady=10)

        self.text_mensajes = tk.Text(self.root, height=10, width=50, wrap=tk.WORD)
        self.text_mensajes.pack(pady=10, fill=tk.BOTH)
        self.text_mensajes.config(state=tk.DISABLED)

        if self.hogar.habitaciones:
            self.habitacion_var.set(self.hogar.habitaciones[0].nombre)
            self.actualizar_controles(self.hogar.habitaciones[0].nombre)

    def set_casa_vacia(self):
        try:
            self.hogar.set_casa_vacia(self.casa_vacia_var.get())
        except Exception as e:
            self.actualizar_mensajes([f"Error al establecer estado de casa vacía: {str(e)}"])

    def actualizar_controles(self, habitacion_nombre):
        try:
            for widget in self.frame_controles.winfo_children():
                widget.destroy()

            habitacion = next((hab for hab in self.hogar.habitaciones if hab.nombre == habitacion_nombre), None)
            if not habitacion:
                return

            for dispositivo in habitacion.dispositivos:
                if isinstance(dispositivo, Luz):
                    self.create_luz_controls(dispositivo)
                elif isinstance(dispositivo, Termostato):
                    self.create_termostato_controls(dispositivo)
                elif isinstance(dispositivo, PersianaInteligente):
                    self.create_persiana_controls(dispositivo)
                elif isinstance(dispositivo, CerraduraInteligente):
                    self.create_cerradura_controls(dispositivo)
                elif isinstance(dispositivo, Sensor):
                    self.create_sensor_controls(dispositivo)
        except Exception as e:
            self.actualizar_mensajes([f"Error al actualizar controles: {str(e)}"])

    def create_luz_controls(self, luz):
        frame = tk.LabelFrame(self.frame_controles, text=luz.nombre)
        frame.pack(pady=5)
        estado_text = "encendida" if luz.encendida else "apagada"
        color = "green" if luz.encendida else "red"
        label_estado = tk.Label(frame, text=f"Estado: {estado_text}", fg=color)
        label_estado.pack()
        label_icono = tk.Label(frame, image=self.icono_encendido if luz.encendida else self.icono_apagado)
        label_icono.pack()
        tk.Button(frame, text="Encender", 
                  command=lambda: self.try_execute(lambda: [luz.encender(), label_estado.config(text="Estado: encendida", fg="green"), label_icono.config(image=self.icono_encendido)], "encender luz")).pack(side=tk.LEFT)
        tk.Button(frame, text="Apagar", 
                  command=lambda: self.try_execute(lambda: [luz.apagar(), label_estado.config(text="Estado: apagada", fg="red"), label_icono.config(image=self.icono_apagado)], "apagar luz")).pack(side=tk.LEFT)

    def create_termostato_controls(self, termostato):
        frame = tk.LabelFrame(self.frame_controles, text=termostato.nombre)
        frame.pack(pady=5)
        label_deseada = tk.Label(frame, text=f"Temp. deseada: {termostato.temperatura_deseada}°C")
        label_deseada.pack()
        label_actual = tk.Label(frame, text=f"Temp. actual: {termostato.temperatura_actual if termostato.temperatura_actual is not None else '--'}°C")
        label_actual.pack()
        entry_temp = tk.Entry(frame, width=5)
        entry_temp.pack(side=tk.LEFT)
        tk.Button(frame, text="Establecer", 
                  command=lambda: self.try_execute(lambda: [termostato.establecer_temperatura(float(entry_temp.get())), label_deseada.config(text=f"Temp. deseada: {termostato.temperatura_deseada}°C")], "establecer temperatura")).pack(side=tk.LEFT)
        tk.Button(frame, text="Leer Temp.", 
                  command=lambda: self.try_execute(lambda: [termostato.leer_temperatura(), label_actual.config(text=f"Temp. actual: {termostato.temperatura_actual:.1f}°C")], "leer temperatura")).pack(side=tk.LEFT)

    def create_persiana_controls(self, persiana):
        frame = tk.LabelFrame(self.frame_controles, text=persiana.nombre)
        frame.pack(pady=5)
        label_nivel = tk.Label(frame, text=f"Nivel: {persiana.nivel}%")
        label_nivel.pack()
        label_icono = tk.Label(frame, image=self.icono_sol if persiana.nivel > 0 else self.icono_luna)
        label_icono.pack()
        escala = tk.Scale(frame, from_=0, to=100, orient=tk.HORIZONTAL, 
                          command=lambda v: self.try_execute(lambda: [persiana.ajustar_nivel(int(v)), label_nivel.config(text=f"Nivel: {persiana.nivel}%"), label_icono.config(image=self.icono_sol if persiana.nivel > 0 else self.icono_luna)], "ajustar persiana"))
        escala.set(persiana.nivel)
        escala.pack()
        tk.Button(frame, text="Abrir", 
                  command=lambda: self.try_execute(lambda: [persiana.abrir(), label_nivel.config(text=f"Nivel: {persiana.nivel}%"), escala.set(persiana.nivel), label_icono.config(image=self.icono_sol)], "abrir persiana")).pack(side=tk.LEFT)
        tk.Button(frame, text="Cerrar", 
                  command=lambda: self.try_execute(lambda: [persiana.cerrar(), label_nivel.config(text=f"Nivel: {persiana.nivel}%"), escala.set(persiana.nivel), label_icono.config(image=self.icono_luna)], "cerrar persiana")).pack(side=tk.LEFT)

    def create_cerradura_controls(self, cerradura):
        frame = tk.LabelFrame(self.frame_controles, text=cerradura.nombre)
        frame.pack(pady=5)
        label_estado = tk.Label(frame, text=f"Estado: {'bloqueada' if cerradura.bloqueada else 'desbloqueada'}")
        label_estado.pack()
        tk.Button(frame, text="Bloquear", 
                  command=lambda: self.try_execute(lambda: [cerradura.bloquear(), label_estado.config(text="Estado: bloqueada")], "bloquear cerradura")).pack(side=tk.LEFT)
        tk.Button(frame, text="Desbloquear", 
                  command=lambda: self.try_execute(lambda: [cerradura.desbloquear(), label_estado.config(text="Estado: desbloqueada")], "desbloquear cerradura")).pack(side=tk.LEFT)

    def create_sensor_controls(self, sensor):
        frame = tk.LabelFrame(self.frame_controles, text=sensor.nombre)
        frame.pack(pady=5)
        label_dato = tk.Label(frame, text=f"Dato: {sensor.dato:.2f}")
        label_dato.pack()
        tk.Button(frame, text="Leer Dato", 
                  command=lambda: self.try_execute(lambda: [sensor.leer_dato(), label_dato.config(text=f"Dato: {sensor.dato:.2f}")], "leer dato sensor")).pack()

    def try_execute(self, func, accion):
        try:
            func()
        except Exception as e:
            self.actualizar_mensajes([f"Error al {accion}: {str(e)}"])

    def verificar_sensores(self):
        try:
            for habitacion in self.hogar.habitaciones:
                for dispositivo in habitacion.dispositivos:
                    if isinstance(dispositivo, Sensor):
                        dispositivo.leer_dato()
                    elif isinstance(dispositivo, Termostato):
                        dispositivo.leer_temperatura()

            for regla in self.reglas:
                regla(self)
        except Exception as e:
            self.actualizar_mensajes([f"Error en verificación de sensores: {str(e)}"])

    def calcular_promedio_temperatura(self):
        try:
            termostato_sala = self.termostato_sala
            termostato_cocina = self.termostato_cocina
            
            if termostato_sala and termostato_cocina:
                if termostato_sala.temperatura_actual is not None and termostato_cocina.temperatura_actual is not None:
                    return (termostato_sala.temperatura_actual + termostato_cocina.temperatura_actual) / 2
            return None
        except Exception as e:
            self.actualizar_mensajes([f"Error al calcular promedio de temperatura: {str(e)}"])
            return None

    def actualizar_mensajes(self, mensajes):
        try:
            self.text_mensajes.config(state=tk.NORMAL)
            for mensaje in mensajes:
                timestamp = datetime.now().strftime("%H:%M:%S")
                self.text_mensajes.insert(tk.END, f"[{timestamp}] {mensaje}\n")
            self.text_mensajes.config(state=tk.DISABLED)
            self.text_mensajes.see(tk.END)
        except Exception as e:
            print(f"Error al actualizar mensajes: {str(e)}")

def verificar_login(usuario, contraseña, root, login_window):
    if usuario == "admin" and contraseña == "1234":  # Credenciales simples
        login_window.destroy()
        root.deiconify()  # Mostrar ventana principal
        app = SmartHomeApp(root)
    else:
        messagebox.showerror("Error", "Usuario o contraseña incorrectos")

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()  # Ocultar ventana principal inicialmente

    login_window = tk.Toplevel(root)
    login_window.title("Login")
    
    tk.Label(login_window, text="Usuario:").pack(pady=5)
    entrada_usuario = tk.Entry(login_window)
    entrada_usuario.pack(pady=5)
    
    tk.Label(login_window, text="Contraseña:").pack(pady=5)
    entrada_contraseña = tk.Entry(login_window, show="*")
    entrada_contraseña.pack(pady=5)
    
    tk.Button(login_window, text="Iniciar Sesión", 
              command=lambda: verificar_login(entrada_usuario.get(), entrada_contraseña.get(), root, login_window)).pack(pady=10)
    
    login_window.protocol("WM_DELETE_WINDOW", root.quit)  # Cerrar todo si se cierra el login
    root.mainloop()