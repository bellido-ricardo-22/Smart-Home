# rules.py
def regla_abrir_persianas_si_calor(app):
    try:
        promedio_temperatura = app.calcular_promedio_temperatura()
        if promedio_temperatura is not None and promedio_temperatura > 23:
            mensajes = []
            for habitacion in [app.sala, app.cocina]:
                for disp in habitacion.dispositivos:
                    if isinstance(disp, app.PersianaInteligente):
                        disp.abrir()
                        mensajes.append(f"Abriendo {disp.nombre} por alta temperatura promedio ({promedio_temperatura:.1f}°C) en Sala y Cocina.")
            app.actualizar_mensajes(mensajes)
    except Exception as e:
        app.actualizar_mensajes([f"Error en regla abrir persianas: {str(e)}"])

def regla_cerrar_persianas_si_frio(app):
    try:
        promedio_temperatura = app.calcular_promedio_temperatura()
        if promedio_temperatura is not None and promedio_temperatura < 12:
            mensajes = []
            for habitacion in [app.sala, app.cocina]:
                for disp in habitacion.dispositivos:
                    if isinstance(disp, app.PersianaInteligente):
                        disp.cerrar()
                        mensajes.append(f"Cerrando {disp.nombre} por baja temperatura promedio ({promedio_temperatura:.1f}°C) en Sala y Cocina.")
            app.actualizar_mensajes(mensajes)
    except Exception as e:
        app.actualizar_mensajes([f"Error en regla cerrar persianas: {str(e)}"])

def regla_encender_luz_si_movimiento(app):
    try:
        for habitacion in app.hogar.habitaciones:
            if habitacion.nombre == "Sala":
                for dispositivo in habitacion.dispositivos:
                    if isinstance(dispositivo, app.Sensor) and "Movimiento" in dispositivo.nombre:
                        if dispositivo.hay_movimiento():
                            for disp in habitacion.dispositivos:
                                if isinstance(disp, app.Luz):
                                    disp.encender()
    except Exception as e:
        app.actualizar_mensajes([f"Error en regla encender luz: {str(e)}"])